﻿using $ext_projectname$.Application.Interfaces;
using $ext_projectname$.Application.Services;
using $ext_projectname$.Domain.Interfaces;
using $ext_projectname$.Infrastructure.Data;
using $ext_projectname$.Infrastructure.Data.Repositories;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
namespace $safeprojectname$
{
    public static class DependencyContainer
    {
        public static void RegisterServices(this IServiceCollection services)
        {
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IUserService, UserService>();
        }
    }
}