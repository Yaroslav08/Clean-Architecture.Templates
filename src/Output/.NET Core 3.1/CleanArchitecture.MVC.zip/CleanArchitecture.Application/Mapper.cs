﻿using AutoMapper;
using $safeprojectname$.ViewModels.User;
using CleanArchitecture.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
namespace $safeprojectname$
{
    public class Mapper : Profile
    {
        public Mapper()
        {
            CreateMap<User, UserViewModel>();
        }
    }
}