﻿using $safeprojectname$.ViewModels.User;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Interfaces
{
    public interface IUserService
    {
        Task<UserViewModel> GetUserById(int id);
    }
}