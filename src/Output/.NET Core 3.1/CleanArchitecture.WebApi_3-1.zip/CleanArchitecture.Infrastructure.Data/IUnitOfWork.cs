﻿using $ext_projectname$.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
namespace $safeprojectname$
{
    public interface IUnitOfWork
    {
        IUserRepository UserRepository { get; }
    }
}