﻿using $ext_projectname$.Domain.Interfaces;
using $ext_projectname$.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
namespace $safeprojectname$.Repositories
{
    public class UserRepository : Repository<User>, IUserRepository
    {

    }
}